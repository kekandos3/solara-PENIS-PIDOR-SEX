local function executeScript(script)
    loadstring(script)()
end

-- Первая команда
executeScript(game:HttpGet('https://raw.githubusercontent.com/lerkermer/lua-projects/master/SwagModeV002'))

-- Остальные команды, выполненные через 5 секунд
wait(5)

_G.Simple = false 
loadstring(game:HttpGet("https://nyulachan.github.io/nyula/Nyula/nyula", true))()

getgenv().tog = false
getgenv().key = "t"
getgenv().X = 68756
getgenv().Y = 100
getgenv().Z = -344

game:GetService("RunService").Heartbeat:Connect(function()
    if getgenv().tog then
        local vel = game.Players.LocalPlayer.Character.HumanoidRootPart.Velocity
        game.Players.LocalPlayer.Character.HumanoidRootPart.Velocity = Vector3.new(getgenv().X, getgenv().Y, getgenv().Z)
        game:GetService("RunService").RenderStepped:Wait()
        game.Players.LocalPlayer.Character.HumanoidRootPart.Velocity = vel
    end
end)

game:GetService("Players").LocalPlayer:GetMouse().KeyDown:Connect(function(keyPressed)
    if keyPressed == string.lower(getgenv().key) then
        pcall(function()
            if getgenv().tog == false then
                getgenv().tog = true
                game.StarterGui:SetCore("SendNotification", {
                    Title = "Actyrn#7104",
                    Text = "AA Enabled" })
            elseif getgenv().tog == true then
                getgenv().tog = false
                game.StarterGui:SetCore("SendNotification", {
                    Title = "Actyrn#7104",
                    Text = "AA Disabled" })
            end
        end)
    end
end)

hookfunction(game.Players.LocalPlayer.IsInGroup, function() return true end)