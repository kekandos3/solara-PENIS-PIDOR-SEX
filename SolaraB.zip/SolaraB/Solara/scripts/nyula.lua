_G.Simple = false 
loadstring(game:HttpGet("https://nyulachan.github.io/nyula/Nyula/nyula", true))()